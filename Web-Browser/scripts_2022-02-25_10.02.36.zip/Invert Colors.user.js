// ==UserScript==
// @name        Invert Colors
// @namespace   english
// @description Invert colors for the websites listed below.
// @include     http*://*brightspace.tudelft.nl*
// @include     http*://*calendar.google.com*
// @version     1.0
// @run-at      document-end
// @grant       GM_addStyle
// ==/UserScript==

var style = document.createElement('style');
style.type = 'text/css';
style.innerHTML = 'html{filter: hue-rotate(180deg)invert(100)contrast(93%) !important ;}html .YO50ue {background: #fff  !important ;}';
document.getElementsByTagName('head')[0].appendChild(style);
